<?php
/**
 * Uninstall CustomGutenberg
 *
 * @since   {VERSION}
 * @link    {URL}
 * @license GPLv2 or later
 * @package CustomGutenberg
 * @author  {AUTHOR}
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
