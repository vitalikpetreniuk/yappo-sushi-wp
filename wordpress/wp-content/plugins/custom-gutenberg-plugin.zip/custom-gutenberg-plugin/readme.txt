=== Plugin Name ===
Contributors: bengreym
Donate link: TODO: Fill ( https://your-donate.link )
Tags: TODO: Fill ( tag1, tag2, tag3 )
Requires at least: 5.6
Tested up to: 8
Stable tag: 1.0.0
Requires PHP: 7.2.5
License: MIT

Plugin description in search plugin.

== Description ==

Plugin description on plugin page.

= Features =
* Feature 1
* Feature 2

== Installation ==

1. Upload `custom-gutenberg` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= FAQ Question 1 =

FAQ Answer 1

= FAQ Question 2 =

FAQ Answer 2

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
* Initial release

== Screenshots ==

1. /assets/img/screenshot-1.png
